import 'package:crud/src/app.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(new MaterialApp(
    home: new App(),
  ));
}
